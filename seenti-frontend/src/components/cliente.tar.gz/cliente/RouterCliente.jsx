// src/components/cliente/RouterCliente.jsx
import { Routes, Route, Navigate } from "react-router-dom";

import CadastroUsuario from "./CadastroUsuario";
import Login from "./Login";
import TermoUso from "./TermoUso";
import CadastroCliente from "./CadastroCliente";
import BoasVindasCliente from "./BoasVindasCliente";
import PaginaCliente from "./PaginaCliente";
import AnamneseCliente from "./AnamneseCliente";

// Função para verificar autenticação
const isClienteAutenticado = () => {
  return !!localStorage.getItem("clienteId");
};

export default function RouterCliente() {
  return (
    <Routes>
      <Route path="/" element={<CadastroUsuario />} />
      <Route path="/login" element={<Login />} />
      <Route path="/termo" element={<TermoUso />} />
      <Route path="/cadastro-cliente" element={<CadastroCliente />} />
      <Route
        path="/boas-vindas"
        element={
          isClienteAutenticado() ? <BoasVindasCliente /> : <Navigate to="/login" />
        }
      />
      <Route
        path="/pagina-cliente"
        element={
          isClienteAutenticado() ? <PaginaCliente /> : <Navigate to="/login" />
        }
      />
      <Route
        path="/anamnese"
        element={
          isClienteAutenticado() ? <AnamneseCliente /> : <Navigate to="/login" />
        }
      />
      <Route path="*" element={<Navigate to="/login" />} />
    </Routes>
  );
}
